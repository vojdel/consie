package controlador;

import static consie.Consie.ventana;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import vista.VNivelPedagogico;

/**
 *
 * @author Diego
 */
public class CNivelPedagogico implements MouseListener {
    VNivelPedagogico vista;

    public CNivelPedagogico() {
        vista = new VNivelPedagogico();
        
        ventana.getContentPane().removeAll();
        ventana.add(vista);
        ventana.setTitle("Nivel Pedagógico");
        ventana.pack();
        addListener();
    }

    private void addListener() {
    }

    @Override
    public void mouseClicked(MouseEvent me) {
    }

    @Override
    public void mousePressed(MouseEvent me) {
    }

    @Override
    public void mouseReleased(MouseEvent me) {
    }

    @Override
    public void mouseEntered(MouseEvent me) {
    }

    @Override
    public void mouseExited(MouseEvent me) {
    }
}
