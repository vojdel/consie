package controlador;

import static consie.Consie.ventana;
import static controlador.CVentana.marco;
import static controlador.CVentana.panelPrincipal;
import general.Funciones;
import general.Validaciones;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.MCargo;
import vista.VCargo;

/**
 *
 * @author Diego
 */
public class CCargo implements ActionListener, MouseListener, KeyListener {

    private VCargo vista;
    private MCargo modelo;

    private DefaultTableModel modeloTabla;
    private MCargo[] datos;

    private Funciones funciones = new Funciones();
    private Validaciones val = new Validaciones();
    private boolean bol = true;
    private String msj = "";

    public CCargo() {
        vista = new VCargo();
        modelo = new MCargo();

        try {
            datos = modelo.selectTodo();
            actualizarTabla(datos);
        } catch (SQLException ex) {
            Logger.getLogger(CCargo.class.getName()).log(Level.SEVERE, null, ex);
        }

        ventana.setTitle("Cargo");
        marco.remove(panelPrincipal);
        vista.setBounds(290, 70, 670, 590);
        marco.add(vista);
        panelPrincipal = vista;
        ventana.repaint();
        ventana.validate();
        vista.getBtnModificar().setEnabled(false);
        vista.getBtnEliminar().setEnabled(false);
        addListener();
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == vista.getBtnNuevo()) {
            vista.getTxtNombre().setText("");
            limpiar();
            vista.getBtnAgregar().setEnabled(true);
            vista.getBtnModificar().setEnabled(false);
            vista.getBtnEliminar().setEnabled(false);
        } else if (ae.getSource() == vista.getBtnAgregar()) {
            validar();

            if (bol) {
                agregar();
            }
        } else if (ae.getSource() == vista.getBtnModificar()) {
            validar();

            if (bol) {
                modificar();
            }
        } else if (ae.getSource() == vista.getBtnEliminar()) {
            int r = JOptionPane.showConfirmDialog(null, "¿Seguro que desea eliminar el registro?", "Advertencia", JOptionPane.YES_NO_OPTION);

            if (r == 0) {
                eliminar();
            }
        }
    }

    @Override
    public void mouseClicked(MouseEvent me) {
        if (me.getSource() == vista.getTabla()) {
            llenarFormulario();
        }
    }

    @Override
    public void mousePressed(MouseEvent me) {
    }

    @Override
    public void mouseReleased(MouseEvent me) {
    }

    @Override
    public void mouseEntered(MouseEvent me) {
    }

    @Override
    public void mouseExited(MouseEvent me) {
    }

    @Override
    public void keyTyped(KeyEvent ke) {
        if (ke.getSource() == vista.getTxtNombre()) {
            val.limite(ke, vista.getTxtNombre().getText(), 50);
            val.soloLetras(ke);
        }
    }

    @Override
    public void keyPressed(KeyEvent ke) {
    }

    @Override
    public void keyReleased(KeyEvent ke) {
        if (ke.getSource() == vista.getTxtNombre()) {
            try {
                String textoBuscar = vista.getTxtNombre().getText();
                datos = modelo.buscar(textoBuscar);
                actualizarTabla(datos);
            } catch (SQLException ex) {
                Logger.getLogger(CCargo.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private void actualizarTabla(MCargo[] datos) {
        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("Nombre");

        vista.getTabla().setModel(modeloTabla);

        if (datos != null) {
            for (MCargo datosX : datos) {
                modelo = datosX;
                modeloTabla.addRow(new Object[]{
                    modelo.getNombre()
                });
            }

            System.out.println("Tabla actualizada");
        }
    }

    private void addListener() {
        vista.getBtnNuevo().addActionListener(this);
        vista.getBtnAgregar().addActionListener(this);
        vista.getBtnModificar().addActionListener(this);
        vista.getBtnEliminar().addActionListener(this);
        vista.getTabla().addMouseListener(this);
        vista.getTxtNombre().addKeyListener(this);
    }

    private void limpiar() {
        vista.getTxtNombre().setText("");
    }

    private boolean validar() {
        bol = true;
        msj = "";

        if (vista.getTxtNombre().getText().isEmpty()) {
            msj = "El campo Nombre no puede estar vacío\n";
            bol = false;
        }

        if (!bol) {
            JOptionPane.showMessageDialog(null, msj, "Advertencia", JOptionPane.WARNING_MESSAGE);
        }

        return true;
    }

    private void agregar() {
        modelo.setNombre(vista.getTxtNombre().getText());

        modelo.insert();

        try {
            datos = modelo.selectTodo();
            actualizarTabla(datos);
        } catch (SQLException ex) {
            Logger.getLogger(CCargo.class.getName()).log(Level.SEVERE, null, ex);
        }

        limpiar();
        vista.getBtnModificar().setEnabled(false);
        vista.getBtnEliminar().setEnabled(false);
    }

    private void modificar() {
        modelo.setNombre(vista.getTxtNombre().getText());

        modelo.update();

        try {
            datos = modelo.selectTodo();
            actualizarTabla(datos);
        } catch (SQLException ex) {
            Logger.getLogger(CCargo.class.getName()).log(Level.SEVERE, null, ex);
        }

        limpiar();
        vista.getBtnAgregar().setEnabled(true);
        vista.getBtnModificar().setEnabled(false);
        vista.getBtnEliminar().setEnabled(false);
    }

    private void eliminar() {
        int filaSeleccionada = vista.getTabla().getSelectedRow();

        if (filaSeleccionada >= 0) {
            int id;
            id = datos[filaSeleccionada].getId();
            modelo.setId(id);
            modelo.delete();

            try {
                datos = modelo.selectTodo();
                actualizarTabla(datos);
            } catch (SQLException ex) {
                Logger.getLogger(CCargo.class.getName()).log(Level.SEVERE, null, ex);
            }

            limpiar();
            vista.getBtnAgregar().setEnabled(true);
            vista.getBtnModificar().setEnabled(false);
            vista.getBtnEliminar().setEnabled(false);
        }
    }

    private void llenarFormulario() {
        int filaSeleccionada = vista.getTabla().getSelectedRow();

        if (filaSeleccionada >= 0) {
            int id;
            id = datos[filaSeleccionada].getId();

            try {
                modelo.select(id);
            } catch (SQLException ex) {
                Logger.getLogger(CCargo.class.getName()).log(Level.SEVERE, null, ex);
            }

            vista.getTxtNombre().setText(modelo.getNombre());

            vista.getBtnAgregar().setEnabled(false);
            vista.getBtnModificar().setEnabled(true);
            vista.getBtnEliminar().setEnabled(true);
        }
    }

}
