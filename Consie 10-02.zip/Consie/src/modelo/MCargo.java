package modelo;

import static consie.Consie.usuarioX;
import general.BD;
import static general.BD.sql;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Diego
 */
public class MCargo {

    private int id;
    private String nombre;

    private BD con = new BD();
    private ResultSet rs;

    public MCargo() {
    }

    public MCargo(int id) {
        this.id = id;
    }

    public MCargo(String nombre) {
        this.nombre = nombre;
    }

    public MCargo(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public MCargo[] selectTodo() throws SQLException {
        sql = "SELECT * FROM cargo "
                + "ORDER BY nombre_cargo;";
        System.out.println(sql);
        con.conectar();
        rs = con.consultarBD();

        if (rs != null) {
            rs.last();
            int contFilas = rs.getRow();
            rs.beforeFirst();

            MCargo[] datos = new MCargo[contFilas];

            for (int i = 0; i < contFilas; i++) {
                rs.next();
                datos[i] = new MCargo(rs.getInt("id_cargo"), rs.getString("nombre_cargo").toUpperCase());
            }

            con.desconectar();
            return datos;
        } else {
            con.desconectar();
            return null;
        }
    }

    public void select(int id) throws SQLException {
        sql = "SELECT * FROM cargo "
                + "WHERE id_cargo='" + id + "';";
        System.out.println(sql);
        con.conectar();
        rs = con.consultarBD();

        if (rs != null) {
            rs.next();
            this.id = rs.getInt("id_cargo");
            this.nombre = rs.getString("nombre_cargo").toUpperCase();
            con.desconectar();
        }
    }

    public MCargo[] buscar(String textoBuscar) throws SQLException {
        textoBuscar = textoBuscar.toLowerCase();
        sql = "SELECT * FROM cargo "
                + "WHERE nombre_cargo LIKE '%" + textoBuscar + "%' "
                + "ORDER BY nombre_cargo";
        System.out.println(sql);
        con.conectar();
        rs = con.consultarBD();

        if (rs != null) {
            rs.last();
            int contFilas = rs.getRow();
            rs.beforeFirst();

            MCargo[] datos = new MCargo[contFilas];

            for (int i = 0; i < contFilas; i++) {
                rs.next();
                datos[i] = new MCargo(rs.getInt("id_cargo"), rs.getString("nombre_cargo").toUpperCase());
            }

            con.desconectar();
            return datos;
        } else {
            con.desconectar();
            return null;
        }
    }

    public void insert() {
        sql = "SELECT agregar_cargo('" + nombre + "', '" + usuarioX.getId() + "');";
        System.out.println(sql);
        con.conectar();
        con.actualizarBD();
        con.desconectar();
    }

    public void update() {
        sql = "SELECT actualizar_cargo('" + id + "', '" + nombre + "', '" + usuarioX.getId() + "');";
        System.out.println(sql);
        con.conectar();
        con.actualizarBD();
        con.desconectar();
    }

    public void delete() {
        sql = "SELECT eliminar_cargo('" + id + "', '" + usuarioX.getId() + "');";
        System.out.println(sql);
        con.conectar();
        con.actualizarBD();
        con.desconectar();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
