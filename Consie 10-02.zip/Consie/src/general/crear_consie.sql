﻿---------- Base de datos: consie ----------
-- CREATE DATABASE consie;
-- DROP DATABASE consie;

---------- Crear tablas ----------
-- cargo
create table if not exists cargo (
	id_cargo serial not null primary key,
	nombre_cargo varchar(30) not null
);

-- estado
CREATE TABLE IF NOT EXISTS estado (
  id_estado int NOT NULL,
  estado varchar(250) NOT NULL,
  iso_3166_2 varchar(4),
  PRIMARY KEY (id_estado)
);

-- grado
create table if not exists grado (
	id_grado serial not null primary key,
	numero int not null
);

-- indicador
create table if not exists indicador (
	id_indicador serial not null primary key,
	nombre_indicador varchar(100) not null,
	prioridad_indicador int not null
);

-- municipio
CREATE TABLE IF NOT EXISTS municipio (
  id_municipio int NOT NULL PRIMARY KEY,
  id_estado int NOT NULL REFERENCES estado (id_estado),
  municipio varchar(100) NOT NULL
);

-- parroquia
CREATE TABLE IF NOT EXISTS parroquia (
  id_parroquia int NOT NULL PRIMARY KEY,
  id_municipio int NOT NULL REFERENCES municipio (id_municipio),
  parroquia varchar(250) NOT NULL
);

-- escuela
create table if not exists escuela (
	id_escuela serial not null primary key,
	nombre_escuela varchar(50) not null,
	turno_escuela varchar(15) not null,
	direccion_escuela text not null,
	id_parroquia int not null references parroquia (id_parroquia)
);
 -- estudiante
create table if not exists estudiante (
	ci_estudiante varchar(10) not null primary key,
	p_nombre_estudiante varchar(20) not null,
	s_nombre_estudiante varchar(20) default '',
	p_apellido_estudiante varchar(20) not null,
	s_apellido_estudiante varchar(20) default '',
	genero_estudiante char not null,
	f_nacimiento_estudiante date,
	direccion_estudiante text not null,
	id_escuela int references escuela (id_escuela)
);
alter table estudiante alter column f_nacimiento_estudiante set default null;
-- personal
create table if not exists personal (
	ci_personal varchar(10) not null primary key,
	p_nombre_personal varchar(20) not null,
	s_nombre_personal varchar(20),
	p_apellido_personal varchar(20) not null,
	s_apellido_personal varchar(20),
	genero_personal varchar(10) not null,
	id_cargo int not null references cargo (id_cargo)
);
-- Puente escuela/personal
create table if not exists escuela_personal (
	id_escuela int not null,
	ci_personal varchar(10) not null,
	foreign key (id_escuela) references escuela (id_escuela),
	foreign key (ci_personal) references personal (ci_personal)
);

-- recaudo
create table if not exists recaudo (
	id_recaudo serial not null primary key,
	nombre_recaudo varchar(200) not null,
	num_frecuencia int not null,
	frecuencia_entrega varchar(10) not null
);

-- Puente escuela/recaudo
create table if not exists escuela_recaudo (
        id_escuela_recaudo serial NOT NULL,
	id_escuela int not null,
	id_recaudo int not null,
        CONSTRAINT pk_ider PRIMARY KEY (id_escuela_recaudo),
	foreign key (id_escuela) references escuela (id_escuela),
	foreign key (id_recaudo) references recaudo (id_recaudo)
);

--
CREATE TABLE entrega_recaudo(
        id_entrega_recaudo serial NOT NULL,
        id_escuela_recuado integer,
        fecha_entrega date,
        CONSTRAINT pk_ers PRIMARY KEY (id_entrega_recaudo),
        CONSTRAINT fk_ers FOREIGN KEY (id_escuela_recuado)
        REFERENCES escuela_recaudo (id_escuela_recaudo) MATCH SIMPLE
        ON UPDATE NO ACTION ON DELETE NO ACTION
);

-- representante
create table if not exists representante (
	ci_representante varchar(10) not null primary key,
	p_nombre_representante varchar(20) not null,
	s_nombre_representante varchar(20),
	p_apellido_representante varchar(20) not null,
	s_apellido_representante varchar(20),
	genero_representante varchar(10) not null
);

-- Puente estudiante/representante
create table if not exists estudiante_representante (
	ci_estudiante varchar(10) not null,
	ci_representante varchar(10) not null,
	foreign key (ci_estudiante) references estudiante (ci_estudiante),
	foreign key (ci_representante) references representante (ci_representante)
);

-- usuario
create table if not exists usuario (
	id_usuario serial not null primary key,
	usuario varchar(15) not null,
	contrasenia varchar(32) not null,
	p_secreta int,
	respuesta varchar(32)
);

-- funcion
create table if not exists funcion (
	id_funcion serial not null primary key,
	funcion varchar(40) not null
);

-- funcionario
create table if not exists funcionario (
	ci_funcionario varchar(10) not null primary key,
	p_nombre_fun varchar(20) not null,
	s_nombre_fun varchar(20),
	p_apellido_fun varchar(20) not null,
	s_apellido_fun varchar(20),
	genero character(1) not null,
	f_nacimiento date,
	telefono varchar(15),
	direccion varchar(200),
	id_cargo int not null,
	id_usuario int,
	foreign key (id_cargo) references cargo (id_cargo),
	foreign key (id_usuario) references usuario (id_usuario)
);

-- Puente usuario/funcion
create table if not exists usuario_funcion (
	id_usuario int not null,
	id_funcion int not null,
	consultar boolean,
	agregar boolean,
	modificar boolean,
	eliminar boolean,
	foreign key (id_usuario) references usuario (id_usuario),
	foreign key (id_funcion) references funcion (id_funcion)
);

-- seccion
create table if not exists seccion (
	id_seccion serial not null primary key,
	descripccion varchar(20) not null
);

-- Puente estudiante/seccion
CREATE TABLE estudiante_seccion (
  id_estudiante varchar(32)  NOT NULL,
  id_seccion int4 NOT NULL,
  CONSTRAINT fk_est3 FOREIGN KEY (id_estudiante) REFERENCES estudiante (ci_estudiante) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT fk_sec3 FOREIGN KEY (id_seccion) REFERENCES seccion (id_seccion) ON DELETE NO ACTION ON UPDATE NO ACTION
);

-- bitacora
create table if not exists bitacora (
	id_bitacora serial not null primary key,
	operacion text not null,
	tabla text not null,
	id_usuario int references usuario (id_usuario),
	valor_viejo text,
	valor_nuevo text,
	fecha_hora timestamp without time zone default localtimestamp(0)
);


---------- Crear Vistas ----------
-- Cargo
create or replace view vista_cargo as
	select
		id_cargo,
		nombre_cargo
	from cargo
	order by nombre_cargo;
	
-- Estado
create or replace view vista_estado as
	SELECT 
		id_estado, 
		estado
	FROM estado
	order by estado;

-- Municipio
create or replace view vista_municipio as
	SELECT 
		m.id_municipio, 
		m.municipio,
		e.id_estado,
		e.estado
	FROM municipio m
	inner join vista_estado e on m.id_estado = e.id_estado;

-- Parroquia
create or replace view vista_parroquia as
	SELECT 
		p.id_parroquia, 
		p.parroquia,
		m.id_municipio,
		m.municipio,
		e.id_estado,
		e.estado
	FROM parroquia p
	inner join municipio m on p.id_municipio = m.id_municipio
	inner join estado e on m.id_estado = e.id_estado;

-- Escuela
create or replace view vista_escuela as
	SELECT 
		esc.id_escuela, 
		esc.nombre_escuela, 
		esc.turno_escuela, 
		esc.direccion_escuela, 
		p.id_parroquia,
		p.parroquia,
		m.id_municipio,
		m.municipio,
		est.id_estado,
		est.estado
	FROM escuela esc
	inner join vista_parroquia p on esc.id_parroquia = p.id_parroquia
	inner join vista_municipio m on p.id_municipio = m.id_municipio
	inner join vista_estado est on m.id_estado = est.id_estado;

-- Estudiante
create or replace view vista_estudiante as 
	SELECT 
		estu.ci_estudiante, 
		estu.p_nombre_estudiante, 
		estu.s_nombre_estudiante, 
		estu.p_apellido_estudiante, 
		estu.s_apellido_estudiante, 
		estu.genero_estudiante, 
		estu.f_nacimiento_estudiante, 
		estu.direccion_estudiante, 
		esc.id_escuela,
		esc.nombre_escuela,
		esc.turno_escuela,
		esc.direccion_escuela,
		p.id_parroquia,
		p.parroquia,
		m.id_municipio,
		m.municipio,
		est.id_estado,
		est.estado
	FROM estudiante estu
	inner join vista_escuela esc on estu.id_escuela = esc.id_escuela
	inner join vista_parroquia p on esc.id_parroquia = p.id_parroquia
	inner join vista_municipio m on p.id_municipio = m.id_municipio
	inner join vista_estado est on m.id_estado = est.id_estado;

-- Funcion
create or replace view vista_funcion as
	SELECT 
		id_funcion, 
		funcion
	FROM funcion;

create or replace view vista_funcionario as
	SELECT 
		f.ci_funcionario, 
		f.p_nombre_fun, 
		f.s_nombre_fun, 
		f.p_apellido_fun, 
		f.s_apellido_fun, 
		f.genero, 
		f.f_nacimiento, 
		f.telefono, 
		f.direccion, 
		c.id_cargo, 
		c.nombre_cargo,
		f.id_usuario
	FROM funcionario f
	inner join cargo c on f.id_cargo = c.id_cargo;

-- Indicador
create or replace view vista_indicador as
	select
		id_indicador,
		nombre_indicador,
		prioridad_indicador
	from indicador
	order by nombre_indicador;


---------- Crear Funciones ----------
---------- INSERTs ----------
-- agregar_cargo()
create or replace function agregar_cargo(nombre2 character varying, id_usuario2 int) returns void as $$
begin
	insert into cargo (nombre_cargo) values (nombre2);
	update bitacora set id_usuario = id_usuario2
	where bitacora.id_bitacora = (select max(id_bitacora) from bitacora);
end;
$$ language plpgsql;
select agregar_cargo('papá', 2);

--agregar_escuela()
create or replace function agregar_escuela(
	nombre2 character varying(50),
	turno2 character varying(15),
	direcion2 character varying,
	id_parroquia2 int,
	id_usuario2 int
) returns void as $$
begin
	insert into escuela (nombre_escuela, turno_escuela, direccion_escuela, id_parroquia)
	values (nombre2, turno2, direccion2, id_parroquia2);
	update bitacora set id_usuario = id_usuario2
	where bitacora.id_bitacora = (select max(id_bitacora) from bitacora);
end;
$$ language plpgsql;

-- agregar_estado()
create or replace function agregar_estado(nombre2 character varying(250), id_usuario2 int) returns void as $$
begin
	insert into estado (nombre_estado) values (nombre2);
	update bitacora set id_usuario = id_usuario2
	where bitacora.id_bitacora = (select max(id_bitacora) from bitacora);
end;
$$ language plpgsql;

-- agregar_estudiante()
create or replace function agregar_estudiante(
	cedula2 character varying(10),
	p_nombre2 character varying(20),
	s_nombre2 character varying(20),
	p_apellido2 character varying(20),
	s_apellido2 character varying(20),
	genero2 char,
	f_nacimiento2 date,
	direccion2 character varying,
	id_usuario2 int
) returns void as $$
begin
	insert into estudiante (
		ci_estudiante,
		p_nombre_estudiante,
		s_nombre_estudiante,
		p_apellido_estudiante,
		s_apellido_estudiante,
		genero_estudiante,
		f_nacimiento_estudiante,
		direccion_estudiante
	) values (
		cedula2,
		p_nombre2,
		s_nombre2,
		p_apellido2,
		s_apellido2,
		genero2,
		f_nacimiento2,
		direccion2
	);
	update bitacora set id_usuario = id_usuario2
	where bitacora.id_bitacora = (select max(id_bitacora) from bitacora);
end;
$$ language plpgsql;

-- agregar_funcionario()
create or replace function agregar_funcionario(
	cedula2 character varying(10),
	p_nombre2 character varying(20),
	s_nombre2 character varying(20),
	p_apellido2 character varying(20),
	s_apellido2 character varying(20),
	genero2 char,
	f_nacimiento2 date,
	telefono2 character varying(15),
	direccion2 character varying,
	id_cargo int,
	id_usuario2 int
) returns void as $$
begin
	insert into funcionario (
		cedula_fun,
		p_nombre_fun,
		s_nombre_fun,
		p_apellido_fun,
		s_apellido_fun,
		genero_fun,
		f_nacimiento_fun,
		telefono_fun,
		direccion_fun,
		id_cargo
	) values (
		cedula2,
		p_nombre2,
		s_nombre2,
		p_apellido2,
		s_apellido2,
		gerero2,
		f_nacimiento2,
		telefono2,
		direccion2,
		id_cargo2
	);
	update bitacora set id_usuario = id_usuario2
	where bitacora.id_bitacora = (select max(id_bitacora) from bitacora);
end;
$$ language plpgsql;

-- agregar_grado()
/*create or replace function agregar_grado(nombre2 varchar(30), id_usuario2 int) returns void as $$
begin
	insert into cargo (nombre_cargo) values (nombre2);
	update bitacora set id_usuario = id_usuario2
	where bitacora.id_bitacora = (select max(id_bitacora) from bitacora);
end;
$$ language plpgsql;*/

create or replace function agregar_indicador(nombre2 varchar(30), prioridad2 int, id_usuario2 int) returns void as $$
begin
	insert into indicador (nombre_indicador, prioridad_indicador) values (nombre2, prioridad2);
	update bitacora set id_usuario = id_usuario2
	where bitacora.id_bitacora = (select max(id_bitacora) from bitacora);
end;
$$ language plpgsql;

/*create or replace function agregar_cargo(nombre2 varchar(30), id_usuario2 int) returns void as $$
begin
	insert into cargo (nombre_cargo) values (nombre2);
	update bitacora set id_usuario = id_usuario2
	where nombre_cargo = nombre2;
end;
$$ language plpgsql;

create or replace function agregar_cargo(nombre2 varchar(30), id_usuario2 int) returns void as $$
begin
	insert into cargo (nombre_cargo) values (nombre2);
	update bitacora set id_usuario = id_usuario2
	where nombre_cargo = nombre2;
end;
$$ language plpgsql;

create or replace function agregar_cargo(nombre2 varchar(30), id_usuario2 int) returns void as $$
begin
	insert into cargo (nombre_cargo) values (nombre2);
	update bitacora set id_usuario = id_usuario2
	where nombre_cargo = nombre2;
end;
$$ language plpgsql;

create or replace function agregar_cargo(nombre2 varchar(30), id_usuario2 int) returns void as $$
begin
	insert into cargo (nombre_cargo) values (nombre2);
	update bitacora set id_usuario = id_usuario2
	where nombre_cargo = nombre2;
end;
$$ language plpgsql;

create or replace function agregar_cargo(nombre2 varchar(30), id_usuario2 int) returns void as $$
begin
	insert into cargo (nombre_cargo) values (nombre2);
	update bitacora set id_usuario = id_usuario2
	where nombre_cargo = nombre2;
end;
$$ language plpgsql;

create or replace function agregar_cargo(nombre2 varchar(30), id_usuario2 int) returns void as $$
begin
	insert into cargo (nombre_cargo) values (nombre2);
	update bitacora set id_usuario = id_usuario2
	where nombre_cargo = nombre2;
end;
$$ language plpgsql;*/

---------- UPDATEs ----------
-- actualizar_cargo
create or replace function actualizar_cargo(id2 int, nombre2 character varying(30), id_usuario2 int) returns void as $$
begin
	update cargo set nombre_cargo = nombre2
	WHERE id_cargo = id2;
	update bitacora set id_usuario = id_usuario2
	where bitacora.id_bitacora = (select max(id_bitacora) from bitacora);
end;
$$ language plpgsql;

-- actualizar_estudiante
create or replace function actualizar_estudiante(
	cedula2 character varying,
	p_nombre2 character varying,
	s_nombre2 character varying,
	p_apellido2 character varying,
	s_apellido2 character varying,
	genero2 char,
	f_nacimiento2 date,
	direccion2 text,
	id_usuario2 int
) returns void as $$
begin
	update estudiante set
		ci_estudiante = cedula2,
		p_nombre_estudiante = p_nombre2,
		s_nombre_estudiante = s_nombre2,
		p_apellido_estudiante = p_apellido2,
		s_apellido_estudiante = s_apellido2,
		genero_estudiante = genero2,
		f_nacimiento_estudiante = f_nacimiento2,
		direccion_estudiante = direccion2
	where ci_estudiante = cedula2;
	update bitacora set id_usuario = id_usuario2
	where bitacora.id_bitacora = (select max(id_bitacora) from bitacora);
end;
$$ language plpgsql;

-- actualizar_indicador
create or replace function actualizar_indicador(id2 int, nombre2 character varying, prioridad2 int, id_usuario2 int) returns void as $$
begin
	update indicador set
		nombre_indicador = nombre2,
		prioridad_indicador = prioridad2
	where id_indicador = id2;
	update bitacora set id_usuario = id_usuario2
	where bitacora.id_bitacora = (select max(id_bitacora) from bitacora);
end;
$$ language plpgsql;

---------- DELETEs ----------
-- eliminar_cargo
create or replace function eliminar_cargo(id2 int, id_usuario2 int) returns void as $$
begin
	delete from cargo where id_cargo = id2;
	update bitacora set id_usuario = id_usuario2
	where bitacora.id_bitacora = (select max(id_bitacora) from bitacora);
end;
$$ language plpgsql;

--eliminar_estudiante
create or replace function eliminar_estudiante(cedula2 character varying, id_usuario2 int) returns void as $$
begin
	delete from estudiante where ci_estudiante = cedula2;
	update bitacora set id_usuario = id_usuario2
	where bitacora.id_bitacora = (select max(id_bitacora) from bitacora);
end;
$$ language plpgsql;

-- eliminar_indicador
create or replace function eliminar_indicador(id2 int, id_usuario2 int) returns void as $$
begin
	delete from indicador where id_indicador = id2;
	update bitacora set id_usuario = id_usuario2
	where bitacora.id_bitacora = (select max(id_bitacora) from bitacora);
end;
$$ language plpgsql;

---------- Otras ----------
-- Calcular edad
create or replace function calcular_edad(f_nacimiento date) returns int as $$
declare	fecha_actual date;
declare dias int;
declare intervalo interval;
declare edad int;
begin
	fecha_actual = current_date;
	dias = fecha_actual - f_nacimiento;
	intervalo = make_interval(days := dias);
	intervalo = justify_days(intervalo);
	intervalo = date_trunc('year', intervalo);
	edad = extract(year from intervalo);
	return edad;
end;
$$ language plpgsql;


---------- Crear Funciones Trigger ----------
CREATE OR REPLACE FUNCTION minusculas_cargo() RETURNS trigger AS $minusculas_cargo$
BEGIN
	NEW.nombre_cargo = lower(NEW.nombre_cargo);
	RETURN NEW;
END;
$minusculas_cargo$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION minusculas_escuela() RETURNS trigger AS $minusculas_escuela$
BEGIN
	NEW.nombre_escuela = lower(NEW.nombre_escuela);
	NEW.turno_escuela = lower(NEW.turno_escuela);
	NEW.direccion_escuela = lower(NEW.direccion_escuela);
	RETURN NEW;
END;
$minusculas_escuela$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION minusculas_estado() RETURNS trigger AS $minusculas_estado$
BEGIN
	NEW.estado = lower(NEW.estado);
	RETURN NEW;
END;
$minusculas_estado$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION minusculas_estudiante() RETURNS trigger AS $minusculas_estudiante$
BEGIN
	NEW.p_nombre_estudiante = lower(NEW.p_nombre_estudiante);
	NEW.s_nombre_estudiante = lower(NEW.s_nombre_estudiante);
	NEW.p_apellido_estudiante = lower(NEW.p_apellido_estudiante);
	NEW.s_apellido_estudiante = lower(NEW.s_apellido_estudiante);
	NEW.genero_estudiante = lower(NEW.genero_estudiante);
	NEW.direccion_estudiante = lower(NEW.direccion_estudiante);
	RETURN NEW;
END;
$minusculas_estudiante$ LANGUAGE plpgsql;

--Bitácora
create or replace function llenar_bitacora() returns trigger as $$
begin
	if TG_OP = 'INSERT' then
		insert into bitacora (operacion, tabla, valor_nuevo)
		values (TG_OP, TG_TABLE_NAME, NEW);
		return NEW;
	end if;
	
	if TG_OP = 'UPDATE' then
		insert into bitacora (operacion, tabla, valor_viejo, valor_nuevo)
		values (TG_OP, TG_TABLE_NAME, OLD, NEW);
		return NEW;
	end if;
	
	if TG_OP = 'DELETE' then
		insert into bitacora (operacion, tabla, valor_viejo)
		values (TG_OP, TG_TABLE_NAME, OLD);
		return OLD;
	end if;
	
	return NEW;
end;
$$ language plpgsql;


---------- Crear Triggers ----------
CREATE TRIGGER tg_minusculas_cargo
BEFORE INSERT OR UPDATE
ON cargo
FOR EACH ROW
EXECUTE PROCEDURE minusculas_cargo();

CREATE TRIGGER tg_minusculas_escuela
BEFORE INSERT OR UPDATE
ON escuela
FOR EACH ROW
EXECUTE PROCEDURE minusculas_escuela();

CREATE TRIGGER tg_minusculas_estado
BEFORE INSERT OR UPDATE
ON estado
FOR EACH ROW
EXECUTE PROCEDURE minusculas_estado();

CREATE TRIGGER tg_minusculas_estudiante
BEFORE INSERT OR UPDATE
ON estudiante
FOR EACH ROW
EXECUTE PROCEDURE minusculas_estudiante();

create trigger tg_bitacora
before insert or update or delete
on cargo
for each row
execute procedure llenar_bitacora();

create trigger tg_bitacora
before insert or update or delete
on indicador
for each row
execute procedure llenar_bitacora();
